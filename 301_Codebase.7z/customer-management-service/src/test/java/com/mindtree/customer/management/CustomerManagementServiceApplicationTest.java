package com.mindtree.customer.management;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * <pre>
 * <b>Description : </b>
 * CustomerManagementServiceApplicationTest.
 * 
 * @version $Revision: 1 $ $Date: 2018-09-25 03:24:22 AM $
 * @author $Author: nithya.pranesh $ 
 * </pre>
 */
@SpringBootTest
public class CustomerManagementServiceApplicationTest {

    @Test
    public void contextLoads() {
    }
}
