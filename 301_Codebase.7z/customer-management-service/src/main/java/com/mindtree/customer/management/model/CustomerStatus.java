/**
 * 
 */
package com.mindtree.customer.management.model;

/**
 * @author M1026341
 *
 */
public enum CustomerStatus {

	/**
	 * ACTIVE.
	 */
	ACTIVE,
	/**
	 * INACTIVE.
	 */
	INACTIVE;
}
