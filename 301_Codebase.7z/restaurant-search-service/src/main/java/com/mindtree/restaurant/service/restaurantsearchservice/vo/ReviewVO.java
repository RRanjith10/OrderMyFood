package com.mindtree.restaurant.service.restaurantsearchservice.vo;

import lombok.Data;

@Data
public class ReviewVO {

	private String restaurantId;

	private String avgRating;
}
